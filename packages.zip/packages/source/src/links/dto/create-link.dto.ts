export class CreateLinkDto {}
